# MYRAA Android

Personal AI companion wrapped as a native Android WebView app. Mobile layout is tuned for narrow screens, touch targets, safe areas and keyboard resizing.

## Build APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's Actions tab.
3. Run **Build MYRAA APK** (or let the push trigger it).
4. Open the completed workflow run and download the `MYRAA-debug-apk` artifact.
5. Extract the artifact ZIP; install `app-debug.apk` on your Android device.

This workflow produces a debug APK, not a Play Store-signed release. API keys are stored in the app's local WebView storage on-device. The AI provider receives prompts when you send them. Provider API usage may cost money. Voice recognition support varies by Android WebView/device; speech output uses the WebView speech engine if available.
